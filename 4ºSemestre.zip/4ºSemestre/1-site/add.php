<?php
header("Content-Type: text/html; charset=ISO-8859-1", true);
	require_once('conexao.php');
	$upload_dir = 'uploads/';



	if(isset($_POST['btnSave'])){

		$cat = $_POST['cat'];
		$titulo = $_POST['titulo'];
		$autor = $_POST['autor'];
		$preco = $_POST['preco'];
		$sinopse = $_POST['sinopse'];

		


		$imgtitulo = $_FILES['arquivo']['name'];
		$imgTmp = $_FILES['arquivo']['tmp_name'];
		$imgSize = $_FILES['arquivo']['size'];


		if(empty($titulo)){
			$errorMsg = 'Por favor informe o titulo';
		}elseif(empty($autor)){
			$errorMsg = 'Por favor informe o autor';
		}elseif(empty($imgtitulo)){
			$errorMsg = 'Por favor selecione a foto';
		}elseif (empty($cat)) {
			$errorMsg = 'Por favor informe a categoria';
		}elseif (empty($preco)) {
			$errorMsg = 'Por favor informe o preço';
		}else{
			//pega a extensão da imagem
			$imgExt = strtolower(pathinfo($imgtitulo, PATHINFO_EXTENSION));
			
			$allowExt  = array('jpeg', 'jpg', 'png', 'gif');
			//cria um novo titulo para a imagem randomicamente 
			$userPic = time().'_'.rand(1000,9999).'.'.$imgExt;
			//verifica se a imagem é valida
			if(in_array($imgExt, $allowExt)){
				//verifica se a imagem tem menos de 5MB
				if($imgSize < 5000000){
					move_uploaded_file($imgTmp ,$upload_dir.$userPic);
				}else{
					$errorMsg = 'Imagem muito grande';
				}
			}else{
				$errorMsg = 'Por favor selecione uma imagem válida';
			}
		}

		//verifica se não houve nenhum erro no upload da imagem e grava no banco de dados
		if(!isset($errorMsg)){

			$sql = "insert into livros(cat, titulo, autor, preco, sinopse, foto)
					values('".$cat."','".$titulo."', '".$autor."', '".$preco."', '".$sinopse."','".$userPic."')";
			$result = mysqli_query($conn, $sql);
			if($result){
				$successMsg = 'Dados gravados com sucesso !!!';
				header('refresh:2;administrativo.php');
			}else{
				$errorMsg = 'Erro '.mysqli_error($conn);
			}
		}

	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Adicionar novos livros</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
</head>
<body>

<div class="navbar navbar-default">
	<div class="container">
		<div class="navbar-header">
			<h3 class="navbar-brand">Upload de novos livros</h3>
		</div>
	</div>
</div>
<div class="container">
	<div class="page-header">
		<h3>Adicionar novo
			<a class="btn btn-default" href="administrativo.php">Voltar</a>
		</h3>
	</div>

	<?php
		if(isset($errorMsg)){		
	?>
		<div class="alert alert-danger">
			<span class="glyphicon glyphicon-info">
				<strong><?php echo $errorMsg; ?></strong>
			</span>
		</div>
	<?php
		}
	?>

	<?php
		if(isset($successMsg)){		
	?>
		<div class="alert alert-success">
			<span class="glyphicon glyphicon-info">
				<strong><?php echo $successMsg; ?> - redirecionando</strong>
			</span>
		</div>
	<?php
		}
	?>

	<form action="" method="post" enctype="multipart/form-data" class="form-horizontal">

		<div class="form-group">
			<label for="cat" class="col-md-2">Categoria</label>
			<div class="col-md-10">
				<input type="text" name="cat" class="form-control">
			</div>
		</div>

		<div class="form-group">
			<label for="titulo" class="col-md-2">T&iacutetulo</label>
			<div class="col-md-10">
				<input type="text" name="titulo" class="form-control">
			</div>
		</div>

		<div class="form-group">
			<label for="autor" class="col-md-2">Autor</label>
			<div class="col-md-10">
				<input type="text" name="autor" class="form-control">
			</div>
		</div>


		<div class="form-group">
			<label for="preco" class="col-md-2">Pre&ccedilo</label>
			<div class="col-md-10">
				<input type="text" name="preco" class="form-control">
			</div>
		</div>
		
		<div class="form-group">
			<label for="sinopse" class="col-md-2">Sinopse</label>
			<div class="col-md-10">
			
                <textarea name="sinopse" class="form-control" rows="4" cols="50"></textarea>
				 
			</div>
		</div>

		<div class="form-group">
			<label for="foto" class="col-md-2">Foto</label>
			<div class="col-md-10">
				<input type="file" name="arquivo">
			</div>
		</div>



		<div class="form-group">
			<label class="col-md-2"></label>
			<div class="col-md-10">
				<button type="submit" class="btn btn-success" name="btnSave">Salvar</button>
			</div>
		</div>

	</form>
</div>

</body>
</html>
