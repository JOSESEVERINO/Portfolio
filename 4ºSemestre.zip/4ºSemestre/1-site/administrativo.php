<?php

session_start();

if(empty($_SESSION['id'])){

   $_SESSION['msg'] = "Insira os dados para acesso";
    header("Location: login.php");
}





header("Content-Type: text/html; charset=ISO-8859-1", true);
	require_once('conexao.php');
	$upload_dir = 'uploads/';
	if(isset($_GET['delete'])){
		$id_livro = $_GET['delete'];

		//seleciona foto gravada no banco de dados
		$sql = "select foto from livros where id = ".$id_livro;

		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) > 0){
			$row = mysqli_fetch_assoc($result);
			$foto = $row['foto'];
			unlink($upload_dir.$foto);
			//deleta dados da tabela
			$sql = "delete from livros where id=".$id_livro;
			if(mysqli_query($conn, $sql)){
				header('location:administrativo.php');
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Livraria</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="icon" href="img/coruja.png">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet"  href="css/style.css" />
        <link rel="stylesheet"  href="css/administrativo.css" />
	</head>
	<body>
	
        <header class="navbar navbar-default">

                <div class="icone">
                    <a href="index.php"><img src="img/corujaicon.png" class="icon"></a>
                </div>
                <form method="GET" action="pesquisar.php" class="pesquisar">
                    <input type="text" class="txtpesquisa" name="pesquisar" placeholder="PESQUISAR">
                    <input type="submit" class="btn btn-default" value="Pesquisar">
                </form><br><br>
                
                <div class="session">
                    <?php
                        echo "Ol&aacute ".$_SESSION['nome'].", bem vindo";

                        
                    ?>
                    <a  class="btn btn-danger" href='sair.php'>Sair</a>
                </div>
                
                <nav  id="navegar">
                    <button   class="dropbt">MENU</button>
                    <ul  class="lista">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="categoria.php">CATEGORIA</a></li>
                       
                    </ul>
                </nav>
                
                
                
            </header>
            
    <div class="container">
            <div class="page-header">
                <a class="btn btn-default" href="add.php">Cadastrar Livro</a><br>
                <h3>Lista de livros</h3>
            </div>
        
	
	
	<table class="table table-bordered table-responsive">
			<thead>
				<tr>
					<th>ID</th>
					<th>Categoria</th>
					<th>T&iacutetulo</th>
					<th>Autor</th>
					<th>Pre&ccedilo</th>
					<th>Capa</th>
					<th>Op&ccedil&otildees</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$sql = "select * from livros";
				$result = mysqli_query($conn, $sql);
				if(mysqli_num_rows($result)){
					while($row = mysqli_fetch_assoc($result)){
			?>
				<tr>
					<td><?php echo $row['id'] ?></td>
					<td><?php echo $row['cat'] ?></td>
					<td><?php echo $row['titulo'] ?></td>
					<td><?php echo $row['autor'] ?></td>
					<td><?php echo $row['preco'] ?></td>
					<td><img src="<?php echo $upload_dir.$row['foto'] ?>" height="40"></td>
					<td>
						<a class="btn btn-info" href="edit.php?id=<?php echo $row['id'] ?>"></span>Editar</a>
						<a class="btn btn-danger" href="administrativo.php?delete=<?php echo $row['id'] ?>" onclick="return confirm('Voc&#519 tem certeza que deseja excluir ?')">Deletar</a>
					</td>
				</tr>
			<?php
					}
				}
			?>
			</tbody>
	</table>
</div>
</div>

<footer>


        </footer>

</body>
</html>
