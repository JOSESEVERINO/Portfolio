<?php
    

    $servidor = "localhost";
    $usuario = "root";
    $senha = "";
    $dbname = "livraria";
    
    
    
    $conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
    
    
    
    
