<?php include_once("conexao.php");
header("Content-Type: text/html; charset=ISO-8859-1", true);

$id_livro = $_GET['id_livro'];

$result_livros = "SELECT * FROM livros WHERE id='$id_livro'";
$resultado_livros = mysqli_query($conn, $result_livros);
$row_livros = mysqli_fetch_assoc($resultado_livros);


$cat = $row_livros['cat'];
$foto = "SELECT * FROM livros WHERE cat='$cat'";
$resultado_livro = mysqli_query($conn, $foto);
$row_livro = mysqli_fetch_assoc($resultado_livro);




?>




<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Livraria</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="icon" href="img/coruja.png">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet"  href="css/style.css" />
        <link rel="stylesheet"  href="css/detalhes.css" />
	</head>
	<body>
	
            <header class="navbar navbar-default">

                <div class="icone">
                    <a href="index.php"><img src="img/corujaicon.png" class="icon"></a>
                </div>
                <form method="GET" action="pesquisar.php" class="pesquisar">
                    <input type="text" class="txtpesquisa" name="pesquisar" placeholder="PESQUISAR">
                    <input type="submit" class="btn btn-default" value="Pesquisar">
                </form><br><br>
                
                
                
                <nav  id="navegar">
                    <button   class="dropbt">MENU</button>
                    <ul  class="lista">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="categoria.php">CATEGORIA</a></li>
                        <li><a href="contato.php">CONTATO</a></li>
                    </ul>
                </nav>
                
                
                
            </header>
            
		<div class="container theme-showcase" role="main">
			<div class="page-header">
				<h1><?php echo $row_livros['titulo']; ?></h1>
			</div>
           
          
            <div>              
                
               
                
                                
                <div class="thumbnail">     
                
                     <div class="capa-detalhes foto-select">
                        <img class="foto" src="uploads/<?php echo $row_livros['foto']; ?>">
                     </div>
                    <div class="detalhes">
                    
                        <p class="bold">Titulo: </p> <p> <?php echo $row_livros['titulo']; ?></p>
                        <p class="bold">Categoria: </p> <p><?php echo $row_livros['cat']; ?></p>
                        <p class="bold">Autor: </p> <p><?php echo $row_livros['autor']; ?></p>
                        <p class="bold">Pre&ccedilo: </p> <p> <?php echo $row_livros['preco']; ?></p>
                        <p class="bold">Sinopse: </p> <p> <?php echo $row_livros['sinopse']; ?></p>
                                        
                        
                    </div>
                    <p><a href="#" class="btn btn-info bt-compra" role="button">Comprar</a> </p>
                </div>
                            
                        
                
                <div class="categoria">
                    <h3><?php echo $row_livros['cat'];?></h3>
                    <?php while($row_livro = mysqli_fetch_assoc($resultado_livro)) { ?>
                    <a href="detalhes.php?id_livro=<?php echo $row_livro['id']; ?>"><img class="foto-select" src="uploads/<?php echo $row_livro['foto']; ?>"></a>
                    <?php } ?>
                </div>
             </div>   
		</div>
		
		
		
		<footer>


        </footer>
	</body>
</html>
