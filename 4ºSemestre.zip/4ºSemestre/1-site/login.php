<?php

session_start();
?>

<!Doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link rel="icon" href="img/coruja.png">
        <title>Login</title>
        
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/signin.css" rel="stylesheet">
    </head>

    <body>
     <div class="container">	
        <h2 class="form-signin-heading text-center">Área restrita</h2>
        
         <h3 class="form-signin-heading text-center"> 
            <?php
                if(isset($_SESSION['msg'])){
                      echo ($_SESSION['msg']);
                      unset ($_SESSION['msg']);
                }
            
            ?>
        </h3>
        
        <form class="form-signin" method="POST" action="valida.php">
            <label class="sr-only">Usuário</label>
            <input type="text" name="usuario" class="form-control" placeholder="Digite seu usuário"><br>
        
            <label class="sr-only">Senha</label>
            <input type="password" name="senha" class="form-control" placeholder="Digite sua senha"><br><br>
            
            <input class="btn btn-info btn-primary btn-block"  type="submit" name="btnLogin" value="Acessar">
        </form>
        
      </div>  
    </body>    
</html>
