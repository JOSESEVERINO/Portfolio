
 
var tam=16;
function mudaFonte(tipo)
{
if (tipo=="mais" && tam < 25)
{
tam+=1;	
}else
{
if(tam>13) tam-=1;
}
document.getElementById('tx').style.fontSize=tam+'px' ;
document.getElementById('tx2').style.fontSize=tam+'px' ;
document.getElementById('quiz').style.fontSize=tam+'px' ;
}

