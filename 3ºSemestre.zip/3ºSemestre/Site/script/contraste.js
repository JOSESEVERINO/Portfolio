$(document).ready(function(){
	$( "#contraste" ).click(function() {
	$( "body,.interface,header,.trs,#afooter,#txtBusca,.divBusca,ul,button,#tx2,#itens,li,table,section,article,aside,div" ).toggleClass( "contraste" );
	 
});
 	
});
