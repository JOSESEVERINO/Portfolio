<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Enntre em contato</title>	
		<link href="./css/style.css" rel="stylesheet">
		<link href="./css/contato.css" rel="stylesheet">
	</head>
	<body>
	
	<nav id="menu">
        <button   class="dropbtn">MENU</button>
        <ul class="dropdown-content">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="vcard.vcf" download> Vcard</a></li>
            <li><a href="eventos.php"> Eventos</a></li>
            <li><a href="contato.php">Contato</a></li>
        </ul>
	</nav>
		
		
	<div id="form-div">
		<h2>Cadastrar Usuário</h2>	
		
		<?php
		if(isset($_SESSION['msg'])){
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
		}
		?>
		<form method="POST" action="processa.php" class="py-5 text-center">
			<label class="container">Nome: </label>
			<input required type="text" name="nome" class="feedback-input" placeholder="Digite o nome completo"><br><br>
			
			<label class="container">E-mail: </label>
			<input required type="email" name="email" placeholder="Digite o seu melhor e-mail" class="feedback-input"><br><br>
			
			<input class="container" type="radio" name="genero" value="Masculino" checked > Masculino
            <input class="container" type="radio" name="genero" value="Feminino" > Feminino<br><br>
			
			<textarea style="resize: none" required rows="4" cols="50"  class="feedback-input" maxlength="300" name="mensagem" placeholder="Digite sua mensagem !!"></textarea><br><br>
			
			<input type="submit" value="Cadastrar" id="button-blue">
		</form>
		
		</div>
		
		<footer>
		<p>José Severino</p>
		
		  <a href="https://www.facebook.com/guigo.guigo.10" target="_blank"><img src="./img/facebook.png" class="midia facebook" alt="Facebook"></a>
        <a href="https://1430831522017-jose-severino.blogspot.com/?view=magazine"  target="_blank"><img src="img/blogger.png" class="midia blogger"></a>  
        
		
		
		</footer>
		
	</body>
</html>
