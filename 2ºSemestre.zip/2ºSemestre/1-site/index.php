<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Início</title>
		<link href="./css/style.css" rel="stylesheet">
		<link href="./css/index.css" rel="stylesheet">
	</head>
	<body>
	
	    <div class="hcard">
            <span class="fn">José Severino S. Silva</span><br>
                     
            <a class="email" href="mailto:guigoatecnica@hotmail.com">E-mail: guigoatecnica@hotmail.com</a>
            <div class="tel">(11)98904-5844</div>
            <div class="adr">
                <div class="street-address">Rua Cuiabá Nº 767</div>
                <span class="locality">Osasco</span>,
                <abbr class="region" title="SaoPaulo">SP</abbr>,
                <span class="postal-code">06226-080</span>
                <div class="country-name">País: Brasil</div>
            </div>    
            <time class="bday">Data Nasc.</time> 17/03/1989
       
    </div>

    
    <nav id="menu">
        <button   class="dropbtn">MENU</button>
        <ul class="dropdown-content">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="vcard.vcf" download> Vcard</a></li>
            <li><a href="eventos.php"> Eventos</a></li>
            <li><a href="contato.php">Contato</a></li>
        </ul>
	
	</nav>
	
	<section id="galeria">
	
            <h2>Linguagens de programação</h2>
		
            <section class="img">
                <img src="./img/2.png" alt="Python" title="Python"> 
                <p>Python</p>
            </section>
            
            <section class="img">
                <img src="./img/3.png" alt="C ++" title="C ++"> 
                <p>C ++</p>
            </section>
		
            <section class="img">
                    <img src="./img/4.jpg" alt="C" title="c"> 
                    <p>C</p>
            </section>
            
            
            <section class="img">
                    <img src="./img/6.jpg" alt="JavaScript" title="JavaScript"> 
                    <p>JavaScript</p>
            </section>
            
            
            <section class="img">
                    <img src="./img/7.png" alt="PHP" title="PHP"> 
                    <p>PHP</p>
            </section>
                
            <section class="img">
                    <img src="./img/8.jpg" alt="Lua" title="Lua"> 
                    <p>Lua</p>
            </section>
                
                
            <section class="img">
                    <img src="./img/9.png" alt="Ruby" title="Ruby"> 
                    <p>Ruby</p>
            </section>
            
            <section class="img">
                    <img src="./img/10.png" alt=".Net" title=".Net"> 
                    <p>.Net</p>
            </section>
		
		
	</section>	
		<footer>
		<p>José Severino</p>
		
		  <a href="https://www.facebook.com/guigo.guigo.10" target="_blank"><img src="./img/facebook.png" class="midia facebook" alt="Facebook"></a>
        <a href="https://1430831522017-jose-severino.blogspot.com/?view=magazine"  target="_blank"><img src="img/blogger.png" class="midia blogger"></a>  
        
		
		
		</footer>
		
		
		
		
		
		
	</body>
</html>
