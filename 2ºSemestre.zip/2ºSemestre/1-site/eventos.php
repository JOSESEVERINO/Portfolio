

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Eventos 2018</title>		
		
		<link href="./css/style.css" rel="stylesheet">
		<link href="./css/eventos.css" rel="stylesheet">
	</head>
	<body>
	
	    
    
    <nav id="menu">
        <button   class="dropbtn">MENU</button>
        <ul class="dropdown-content">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="vcard.vcf" download> Vcard</a></li>
            <li><a href="eventos.php"> Eventos</a></li>
            <li><a href="contato.php">Contato</a></li>
        </ul>
     </nav>   
	
	<section class="container">
	
        <h1> Eventos 2018</h2>
	
        
            <div class="vevent left" id="hcalendar--Campus-Party-Brasil">
                <h2>Campus Party Brasil 2018</h2><br>
                SITE: <a class="url" href="http://brasil.campus-party.org/">http://brasil.campus-party.org/</a><br>
                <time datetime="2018-02-12" class="dtstart">DATA: 12 até 17 de fevereiro </time><br><br> 
               
                <span class="location">ENDEREÇO: Rua José Bernado Pinto, 333- Vila Guilherme, Expo Center Norte</span><br><br> 
                </a><div class="description">A Campus Party Brasil é o principal acontecimento tecnológico realizado anualmente no Brasil. Nele são tratados os mais diversos temas relacionados à Internet, reunindo um grande número de comunidades e usuários da rede mundial de computadores envolvidos com tecnologia e cultura digital. As edições já realizadas no Brasil ocorreram a partir de 2008 até 2017 na cidade de São Paulo, e em Recife a partir de 2012 até 2015.<br>

Na última edição do evento em São Paulo foi anunciado que, durante 2016, ocorrerão edições da Campus Party também em Brasília e Belo Horizonte, além da edição em Recife. </div>

            </div>
            
            <div class="vevent right" id="hcalendar--Brasil-Game-Show">
                <h2>Brasil Game Show 2018</h2><br>
                SITE: <a class="url" href="http://www.brasilgameshow.com.br/">http://www.brasilgameshow.com.br/</a><br>
                <time datetime="2018-02-10" class="dtstart">DATA: 10 até 14 de Outubro </time><br><br> 
               
                <span class="location">ENDEREÇO: Rua José Bernado Pinto, 333- Vila Guilherme, Expo Center Norte</span><br><br> 
                </a><div class="description">A Brasil Game Show (ou BGS) é uma feira anual de videogames organizada pelo empresário Marcelo Tavares, atualmente realizada em São Paulo, Brasil. A feira é considerada a maior conferência do gênero em toda a América Latina. </div>

            </div>
            
            
             <div class="vevent right" id="hcalendar--Roadsec">
                <h2>Roadsec 2018</h2><br>
                SITE: <a class="url" href="https://roadsec.com.br/">https://roadsec.com.br/</a><br>
                <time datetime="2018-02-12" class="dtstart">DATA: 10 de novembro </time><br><br> 
               
                <span class="location">ENDEREÇO: Av. Francisco Matarazzo, 694 Barra Funda - São Paulo</span><br><br> 
                </a><div class="description">O Roadsec é um evento itinerante que percorre diversos estados brasileiros levando uma mistura única de palestras, atividades e campeonatos, integrando estudantes, profissionais e comunidades em torno da celebração da cultura hacker em todas as suas vertentes: segurança, desenvolvimento, makers e ativistas. Esse giro acaba em São Paulo num dos maiores festivais do gênero no planeta, misturando conhecimento, atividades, cultura, gastronomia, música e muito networking com a nata do hacking brasileiro! </div>
                </div>
            
            
            <div class="vevent left" id="hcalendar--Big-Data-Week-São-Paulo">
                <h2>Big Data Week São Paulo 2018</h2><br>
                SITE: <a class="url" href="http://sao-paulo.bigdataweek.com/">http://sao-paulo.bigdataweek.com/</a><br>
                <time datetime="2018-10-20" class="dtstart">DATA: 20 de Outubro </time><br><br> 
               
                <span class="location">ENDEREÇO: Centro de Convenções Rebouças Av. Dr. Enéas de Carvalho Aguiar, 23 – Pinheiros, São Paulo </span><br><br> 
                </a><div class="description">O Big Data Week é um conferência internacional criada em Londres em 2012 e promovida em várias cidades ao redor do mundo. Ela reúne uma comunidade global de profissionais de tecnologia, entusiastas e especialistas de big data, data science e internet das coisas para discutir novas tendências, desafios e o avanço global das tecnologias e soluções.

                </div>

            </div>
	
	</section>
		<footer>
		<p>José Severino</p>
		
		  <a href="https://www.facebook.com/guigo.guigo.10" target="_blank"><img src="./img/facebook.png" class="midia facebook" alt="Facebook"></a>
        <a href="https://1430831522017-jose-severino.blogspot.com/?view=magazine"  target="_blank"><img src="img/blogger.png" class="midia blogger"></a>  
        
		
		
		</footer>
		
		
		
		
		
		
	</body>
</html>
