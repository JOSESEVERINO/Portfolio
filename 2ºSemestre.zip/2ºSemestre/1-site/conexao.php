<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "contato";
//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
