package com.example.root.trabalho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class RespostaActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resposta);


        ImageView imgResposta = (ImageView)findViewById(R.id.imgResposta);
        TextView resposta = (TextView)findViewById(R.id.resposta);
        Button btnJogarNovamente = (Button)findViewById(R.id.btnJogarNovamente);

        Intent intent = getIntent();
        int pontos = intent.getIntExtra("pontos", 0);

        if(intent.hasExtra("acertou")) {
            btnJogarNovamente.setVisibility(View.INVISIBLE);
            boolean acertou = intent.getBooleanExtra("acertou", false);
            if (acertou) {
                imgResposta.setImageResource(R.drawable.correct);
                resposta.setText("Acertou!\nPontuação: " + pontos);
            } else {
                imgResposta.setImageResource(R.drawable.incorrect);
                resposta.setText("Errou!\nPontuação: " + pontos);
            }

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    finish();
                }
            });
            thread.start();
        }
        else{
            btnJogarNovamente.setVisibility(View.VISIBLE);
            resposta.setText("Você fez " + pontos + " ponto(s) de 20");


        }
    }


    public void btnJogarNovamenteOnClick(View v){
        Intent intent = new Intent(this, QuizActivity.class);
        startActivity(intent);
        finish();
    }

    /**
     * Created by root on 03/12/17.
     */

    public static class Questao {

        private String pergunta;
        private List<String> respostas = new ArrayList<>();
        private int respostaCerta;
        private int imgPergunta;

        public Questao(int imgPergunta, String pergunta, int respostaCerta, String... respostas){
            this.imgPergunta= imgPergunta;
            this.pergunta = pergunta;
            this.respostas.add(respostas[0]);
            this.respostas.add(respostas[1]);
            this.respostas.add(respostas[2]);
            this.respostas.add(respostas[3]);
            this.respostaCerta = respostaCerta;
        }

        public String getPergunta(){ return this.pergunta; }
        public List<String> getRespostas(){ return this.respostas; }
        public int getRespostaCerta(){ return this.respostaCerta; }
        public int getImgPergunta() { return this.imgPergunta; }
    }
}
