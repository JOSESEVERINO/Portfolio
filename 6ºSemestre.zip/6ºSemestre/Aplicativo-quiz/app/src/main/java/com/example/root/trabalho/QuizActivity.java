package com.example.root.trabalho;


import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class QuizActivity extends AppCompatActivity {



    TextView pergunta;
    RadioButton rbResposta1, rbResposta2, rbResposta3, rbResposta4;
    ImageView imgPergunta;
    RadioGroup rgRespostas;
    int respostaCerta;
    int pontos;
    List<Questao> questoes = new ArrayList<Questao>(){
        {
            add(new Questao(R.drawable.brasil,"I'm the capital of Brasil", R.id.rbResposta4, "São Paulo", "Rio de Janeiro", "Curitiba", "Brasilia"));
            add(new Questao(R.drawable.china, "I'm the capital of China", R.id.rbResposta1, "Pequim", "Xangai", "Hong Kong", "Hangzhou"));
            add(new Questao(R.drawable.alemanha, "I'm the capital of Alemanha", R.id.rbResposta2, "Hamburgo", "Berlim", "Munique", "Frankfurt"));
            add(new Questao(R.drawable.afeganistao, "I'm the capital of Afeganistão", R.id.rbResposta4, "Charikar", "Gázni", "Herat", "Cabul"));
            add(new Questao(R.drawable.africa_sul, "I'm the capital of África do Sul", R.id.rbResposta3,  "Joanesburgo", "Bloemfontein", "Pretória", "Durban"));
            add(new Questao(R.drawable.albania, "I'm the capital of Albânia", R.id.rbResposta1, "Tirana", "Durrës", "Elbasani", "Vlorë"));
            add(new Questao(R.drawable.andora, "I'm the capital of Andorra", R.id.rbResposta2, "Escaldes-Engordany", "Andorra-a-Velha", "Sant Julià de Lòria", "Encamp"));
            add(new Questao(R.drawable.angola, "I'm the capital of Angola", R.id.rbResposta3, "Huambo", "Lobito", "Luanda", "Benguela"));
            add(new Questao(R.drawable.arabie_saoudite, "I'm the capital of Arábia Saudita", R.id.rbResposta4, "Medina", "Meca", "Jeddah", "Riade"));
            add(new Questao(R.drawable.algerie, "I'm the capital of Argélia", R.id.rbResposta1, "Argel", "Orã", "Constantina", "Annaba"));

            add(new Questao(R.drawable.argentine, "I'm the capital of Argentina", R.id.rbResposta2, "Córdoba", "Buenos Aires", "Rosário", "Mendoza"));
            add(new Questao(R.drawable.australie, "I'm the capital of Austrália", R.id.rbResposta3, "Melbourne", "Brisbane", "Camberra", "Adelaide"));
            add(new Questao(R.drawable.ruanda, "I'm the capital of Ruanda", R.id.rbResposta4, "Ruhengeri", "Gitarama", "Butare", "Kigali"));
            add(new Questao(R.drawable.russie, "I'm the capital of Rússia", R.id.rbResposta1, "Moscou", "São Petersburgo", "Novosibirsk", "Ecaterimburgo"));
            add(new Questao(R.drawable.suede, "I'm the capital of Suécia", R.id.rbResposta2, "Gotemburgo", "Estocolmo", "Malmö", "Uppsala"));
            add(new Questao(R.drawable.suisse, "I'm the capital of Suiça", R.id.rbResposta1, "Berna", "Genebra", "Basileia", "Zurique"));
            add(new Questao(R.drawable.japan, "I'm the capital of Japão", R.id.rbResposta4, "Nagoia", "Osaka", "Yokohama", "Tóquio"));
            add(new Questao(R.drawable.liberia, "I'm the capital of Libéria", R.id.rbResposta3, "Kakata", "Gbanrga", "Monróvia", "Bensonville"));

            add(new Questao(R.drawable.luxembourg, "I'm the capital of Luxemburgo", R.id.rbResposta4, "Grevenmacher", "Echternach", "Ettelbruck", "Luxemburgo"));
            add(new Questao(R.drawable.india, "I'm the capital of India", R.id.rbResposta2, "Bombaim", "Nova Deli", "Calcutá", "Bangalore"));


        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        imgPergunta = (ImageView)findViewById(R.id.imgPergunta);
        pergunta = (TextView)findViewById(R.id.pergunta);
        rgRespostas = (RadioGroup)findViewById(R.id.rgRespostas);
        rbResposta1 = (RadioButton)findViewById(R.id.rbResposta1);
        rbResposta2 = (RadioButton)findViewById(R.id.rbResposta2);
        rbResposta3 = (RadioButton)findViewById(R.id.rbResposta3);
        rbResposta4 = (RadioButton)findViewById(R.id.rbResposta4);
        carregarQuestao();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        carregarQuestao();
    }

    public void btnResponderOnClick(View v){
        RadioButton rb = (RadioButton)findViewById(rgRespostas.getCheckedRadioButtonId());
        Intent intent = new Intent(this, RespostaActivity.class);
        if(rgRespostas.getCheckedRadioButtonId() == respostaCerta) {
            intent.putExtra("acertou", true);
            pontos++;
        }
        else intent.putExtra("acertou", false);
        intent.putExtra("pontos", pontos);
        startActivity(intent);
        rb.setChecked(false);
    }

    private void carregarQuestao(){

        embaralhar(questoes);

        if(questoes.size() > 0) {
            Questao q = questoes.remove(0);
            pergunta.setText(q.getPergunta());
            imgPergunta.setImageResource(q.getImgPergunta());
            List<String> resposta = q.getRespostas();
            rbResposta1.setText(resposta.get(0));
            rbResposta2.setText(resposta.get(1));
            rbResposta3.setText(resposta.get(2));
            rbResposta4.setText(resposta.get(3));
            respostaCerta = q.getRespostaCerta();
            rgRespostas.setSelected(false);
        }
        else{ //acabaram as questões
            Intent intent = new Intent(this, RespostaActivity.class);
            intent.putExtra("pontos", pontos);
            startActivity(intent);
            finish();
        }
    }

    public void embaralhar(List<Questao> questoes){
        Collections.shuffle(questoes);
    }
}