package com.example.root.trabalho;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 03/12/17.
 */

class Questao {

    private String pergunta;
    private List<String> respostas = new ArrayList<>();
    private int respostaCerta;
    private int imgPergunta;

    public Questao(int imgPergunta, String pergunta, int respostaCerta, String... respostas){
        this.imgPergunta= imgPergunta;
        this.pergunta = pergunta;
        this.respostas.add(respostas[0]);
        this.respostas.add(respostas[1]);
        this.respostas.add(respostas[2]);
        this.respostas.add(respostas[3]);
        this.respostaCerta = respostaCerta;
    }

    public String getPergunta(){ return this.pergunta; }
    public List<String> getRespostas(){ return this.respostas; }
    public int getRespostaCerta(){ return this.respostaCerta; }
    public int getImgPergunta() { return this.imgPergunta; }
}
